# Official FlyVis reference screen

**Result: PASS**

This is one frozen, optic-flow-trained FlyVis model on its own published visual connectome. It does not validate the MaleCNS retinal mapping, decoder, conditioning or game-learning gates. The weights were not trained on Scicon or changed for this experiment.

| Engineering criterion | Result |
|---|---|
| finite | PASS |
| targetsNontrivial | PASS |
| l1L2FlashPolarity | PASS |
| contrastSelectivity | PASS |
| preferredVersusOpponent | PASS |
| repeatDeterminism | PASS |
| blankStability | PASS |
| parametersUnchanged | PASS |
| sourcesUnchanged | PASS |

Preregistered engineering screen of one optic-flow-trained model. Thresholds are not physiological fits, biological population confidence intervals or an assertion that every published result is reproduced. Six-of-eight polarity/direction criteria expose per-cell failures rather than selecting cells after seeing results.

All stimulus and central response arrays, source cell indices, parameters and runtime hashes are included. The blank and repeated inputs are freshly simulated; no response-cache hit can satisfy determinism.

![Flash responses](flash-responses.png)
![Edge tuning](edge-tuning.png)

[Official model and paper](https://www.nature.com/articles/s41586-024-07939-3)
[Frozen source dynamics](https://github.com/TuragaLab/flyvis/blob/v1.2.0/flyvis/network/dynamics.py)
